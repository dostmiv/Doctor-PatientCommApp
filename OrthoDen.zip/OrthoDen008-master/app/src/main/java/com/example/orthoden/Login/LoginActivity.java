package com.example.orthoden.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.orthoden.R;

public class LoginActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doktor_login);
    }
}
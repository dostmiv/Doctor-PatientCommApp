package com.example.orthoden.Login2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import com.example.orthoden.MainActivity;
import com.example.orthoden.R;

public class DoktorWelcomeActivity extends AppCompatActivity {
    TextView tvWelcome;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_doktor_welcome);
        tvWelcome=findViewById(R.id.tv_Welcome);
        String userName=getIntent().getStringExtra("USERNAME");
        tvWelcome.setText(userName);
    }
    public void returnMainMenu(View view){
        Intent myIntent = new Intent(DoktorWelcomeActivity.this, DoktorMainActivity.class);
        myIntent.putExtra("key", 1); //Optional parameters
        DoktorWelcomeActivity.this.startActivity(myIntent);
        Intent intent = getIntent();
        String value = intent.getStringExtra("key");
    }
}
package com.example.orthoden.Login2;
    import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

    import com.example.orthoden.MainActivity;
    import com.example.orthoden.R;

public class DoktorLoginActivity extends AppCompatActivity {

        EditText etLoginUN,etLoginPass;
        TextView tvNewUser;
        Button btnLogin, btnViewUsers;
    public void returnMainMenu(){
        Intent myIntent = new Intent(DoktorLoginActivity.this, MainActivity.class);
        myIntent.putExtra("key", 1); //Optional parameters
        DoktorLoginActivity.this.startActivity(myIntent);

        Intent intent = getIntent();
        String value = intent.getStringExtra("key");
    }
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_doktor_login);
            etLoginPass=findViewById(R.id.et_LoginPass);
            etLoginUN=findViewById(R.id.et_LoginUN);
            btnLogin=findViewById(R.id.btn_Login);
            tvNewUser=findViewById(R.id.tv_NewUser);
            btnViewUsers=findViewById(R.id.btn_AllUsers);


            btnLogin.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    String userName=etLoginUN.getText().toString();
                    String password=etLoginPass.getText().toString();
                    if(!TextUtils.isEmpty(userName)&& !TextUtils.isEmpty(password)){
                        DatabaseClass databaseObject=new DatabaseClass(DoktorLoginActivity.this);
                        String realPassword=databaseObject.findUser(userName);
                        if(password.equals(realPassword)){
                            Intent i=new Intent(DoktorLoginActivity.this,DoktorWelcomeActivity.class);
                            i.putExtra("USERNAME",userName);
                            startActivity(i);
                        }else
                            Toast.makeText(getApplicationContext(),"Username or password is wrong",Toast.LENGTH_SHORT).show();
                    }
                }
            });

            tvNewUser.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i=new Intent(DoktorLoginActivity.this,DoktorRegisterActivity.class);
                    startActivity(i);
                }
            });

            btnViewUsers.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    Intent i=new Intent(DoktorLoginActivity.this,ViewUserActivity.class);
                    startActivity(i);
                }
            });
        }
    }

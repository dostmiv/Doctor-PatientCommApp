package com.example.orthoden.Login;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.orthoden.Login2.DoktorLoginActivity;
import com.example.orthoden.Login2.HastaLoginActivity;
import com.example.orthoden.MainActivity;
import com.example.orthoden.R;
import com.example.orthoden.fuctions.MailActivity;

public class StartPage extends AppCompatActivity {
    Button doktorgirisbtn,hastagirisbtn;
    Intent intent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_start_page);
        doktorgirisbtn = findViewById(R.id.doktorgirisbtn);
        hastagirisbtn = findViewById(R.id.hastagirisbtn);

        doktorgirisbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(StartPage.this, DoktorLoginActivity.class);
                startActivity(intent);
            }
        });

        hastagirisbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(StartPage.this, HastaLoginActivity.class);
                startActivity(intent);
            }
        });

    }


}